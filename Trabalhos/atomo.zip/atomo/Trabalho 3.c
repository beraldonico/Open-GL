/*
MOUSE
    RIGHT 
    LEFT	start/ stop
    MIDDLE 	restart zoom
    Scrool 	zoom in and out
KEY
    LEFT    	|
    UP      	|
    DOWN    	| Move camera
    RIGHT   	|
    PAGE UP		|
    PAGE DOWN	|
    HOME	Invert camera
    F1 		decrease speed
    F2 		increase speed
    F3 		reset speed
    F4 		reset camera
    F12 	stop program
*/

#include <GL/glew.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <CImg.h>

//variaveis
GLint rot = 0;
static GLfloat spin = 0.0;
GLfloat velo = 1.0;
GLint width, height;
GLdouble move_cx = 100.0;
GLdouble move_cy = 50.0;
GLdouble move_cz = -100.0;
GLdouble move_fz = 0.0;
GLdouble move_uy = 1.0;
GLfloat fovy = 45.0;
GLint programId;
static GLuint textures[4];

//funções
void initShaders();
GLuint loadShaders(const char *vsPath, const char *fsPath);
GLint loadShader(GLuint shaderId, const char *path);
void init(void);
void loadTexture(const char* imgPath, int texID);
void display(void);
void particula(int ID, double radius, int slices, int stacks);
void reshape(int w, int h);
void mouse(int button, int state, int x, int y);
void motion(int x, int y);
void special(int key, int x, int y);

int main(int argc, char** argv)
{
    // inicia GLUt e cria janela
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_DEPTH |GLUT_RGBA);
    glutInitWindowSize (927, 560);
    glutInitWindowPosition (0, 0);
    glutCreateWindow ("Trabalho 3");

    // inicia opções da janela
    initShaders();
    init ();

    // desenha o objeto
    glutDisplayFunc(display);

    // funções do GLUT
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutPassiveMotionFunc(motion);
    glutSpecialFunc(special);

    // processo de loop do GLUT
    glutMainLoop();

    return 0;
}

void initShaders()
{
    GLenum err = glewInit();
    if (GLEW_OK != err)
        fprintf(stderr, "%s\n", glewGetErrorString(err));

    programId = loadShaders("shaders/vertex.glsl","shaders/fragment.glsl");
}

GLuint loadShaders(const char *vsPath, const char *fsPath)
{
    GLuint vsId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fsId = glCreateShader(GL_FRAGMENT_SHADER);

    loadShader(vsId, vsPath);
    loadShader(fsId, fsPath);

    GLuint progId = glCreateProgram();
    glAttachShader(progId, vsId);
    glAttachShader(progId, fsId);
    glLinkProgram(progId);

    GLint ret = GL_FALSE;
    int infoLogLength;
    glGetProgramiv(progId, GL_LINK_STATUS, &ret);
    glGetProgramiv(progId, GL_INFO_LOG_LENGTH, &infoLogLength);
    if ( infoLogLength > 0 )
    {
        char msg[4096];
        glGetProgramInfoLog(progId, infoLogLength, NULL, msg);
        printf("%s\n", msg);
    }

    glDetachShader(progId, vsId);
    glDetachShader(progId, fsId);

    glDeleteShader(vsId);
    glDeleteShader(fsId);

    glUseProgram(progId);

    GLuint t0 = glGetUniformLocation(progId, "normalTexture");
    GLuint t1 = glGetUniformLocation(progId, "colorTexture");

    glUniform1i(t0, 0);
    glUniform1i(t1, 1);

    glUseProgram(0);

    return progId;
}

GLint loadShader(GLuint shaderId, const char *path)
{
    FILE *file = fopen(path,"r");
    if (file == NULL)
    {
        fprintf(stderr, "Couldn't open file %s for reading\n", path);
        return GL_FALSE;
    }
    int codeBufferSize = 4096;
    int codeSize = 0;
    char *code = (char*)malloc(codeBufferSize * sizeof(char));
    if (code == NULL)
    {
        fprintf(stderr, "Failed to request %d bytes of memory\n", codeBufferSize);
        return GL_FALSE;
    }
    int rl = 256;
    int r = 0;
    int i = 0;
    while ((r = fread(&code[i], 1, rl, file)) > 0)
    {
        i += r;
        if ((i + rl) > (codeBufferSize - 1))
        {
            codeBufferSize *= 2;
            char *newCode = (char*)malloc(codeBufferSize * sizeof(char));
            if (newCode == NULL)
            {
                fprintf(stderr, "Failed to request %d bytes of memory\n", codeBufferSize);
                free(code);
                return GL_FALSE;
            }
            for (int j = 0; j < i; j++)
            {
                code[j] = newCode[j];
            }
            free(code);
            code = newCode;
        }
    }
    code[i] = '\0';
    //printf("%s\n", code);

    const char *src = code;
    glShaderSource(shaderId, 1, &src, NULL);
    glCompileShader(shaderId);

    GLint ret = GL_FALSE;
    int infoLogLength;
    glGetShaderiv(shaderId, GL_COMPILE_STATUS, &ret);
    glGetShaderiv(shaderId, GL_INFO_LOG_LENGTH, &infoLogLength);
    if ( infoLogLength > 0 )
    {
        char msg[4096];
        glGetShaderInfoLog(shaderId, infoLogLength, NULL, msg);
        printf("%s\n", msg);
    }
}

void init(void)
{
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    loadTexture("textures/sol.jpg", 0);
    loadTexture("textures/netuno.jpg", 1);
    loadTexture("textures/urano.jpg", 2);
    loadTexture("textures/ouro.jpg", 3);
}

void loadTexture(const char* imgPath, int texID)
{
    cimg_library::CImg<unsigned char> image(imgPath);
    GLubyte *imgBuffer = (GLubyte*)malloc(image.width() * image.height() * 4 * sizeof(GLubyte));
    cimg_forXY(image,x,y)
    {
        imgBuffer[(image.width() * y + x) * 4 + 0] = image(x,y,0);
        imgBuffer[(image.width() * y + x) * 4 + 1] = image(x,y,1);
        imgBuffer[(image.width() * y + x) * 4 + 2] = image(x,y,2);
        imgBuffer[(image.width() * y + x) * 4 + 3] = 1.0;
    };

    GLsizei width = image.width();
    GLsizei height = image.height();

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glGenTextures(1, &textures[texID]);
    glBindTexture(GL_TEXTURE_2D, textures[texID]);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);// GL_MIRRORED_REPEAT// GL_CLAMP_TO_EDGE
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);// GL_MIRRORED_REPEAT//GL_CLAMP_TO_EDGE
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width,
                 height, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                 imgBuffer);
    glGenerateMipmap(GL_TEXTURE_2D);

    free(imgBuffer);
}

void display(void)
{
    if (rot)
    {
        spin += velo;
        if (spin > 360.0)
            spin -= 360.0;
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glUseProgram(programId);

    glPushMatrix();
    
    //cores
    GLfloat vermelho[4] = {1.0f, 0.0f, 0.0f, 1.0f};
    GLfloat branco[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    GLfloat verde[4] = {0.0f, 1.0f, 0.0f, 1.0f};
    GLfloat preto[4] = {0.0f, 0.0f, 0.0f, 1.0f};

    for(int i = 0; i < 5; i++)
    {
        for(int j = 0; j < 5; j++)
        {
            glPushMatrix();
            	if( i == 0 && j == 0)
            	{
            		glMaterialfv(GL_FRONT, GL_EMISSION, branco);
            	}
            	glTranslatef(i * 100.0, 0.0, j * 100.0);	
        		//nucleo
    			//4 Protons
            	glPushMatrix();
            		glTranslatef(0.0,2.0,0.0);
            		particula(0, 2.5, 25.0, 25.0);
           		glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(0.0,-2.0,0.0);
            		particula(0, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(2.0,0.0,0.0);
           		 	particula(0, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
           		 	glTranslatef(-2.0,0.0,0.0);
            		particula(0, 2.5, 25.0, 25.0);
            	glPopMatrix();


            	//5 Neutrons
            	glPushMatrix();
            		glTranslatef(0.0,0.0,0.0);
            		particula(2, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(1.20,1.20,0.0);
            		glutSolidSphere(2.5, 25.0, 25.0);
            		particula(2, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(-1.20,-1.20,0.0);
            		particula(2, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(-1.20,1.20,0.0);
            		particula(2, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	//
            	glPushMatrix();
            		glTranslatef(1.20,-1.20,0.0);
            		particula(2, 2.5, 25.0, 25.0);
            	glPopMatrix();
            	
            	glMaterialfv(GL_FRONT, GL_EMISSION, preto);

            	//eletron 1 horinzontal
            	glPushMatrix();
            		glRotatef(spin, 0.0, 1.0, 0.0);
            		//
            		glPushMatrix();
            			glTranslatef(40.0,0.0,0.0);
            			particula(1, 2.5, 50.0, 50.0);
            		glPopMatrix();
            		//
            	glPopMatrix();
            	//
            	//eletron 2 vertical
            	glPushMatrix();
            		glRotatef(spin, 1.0, 0.0, 0.0);
            		//
            		glPushMatrix();
            			glTranslatef(0.0,40.0,0.0);
            			particula(1, 2.5, 50.0, 50.0);
            		glPopMatrix();
            		//
           		glPopMatrix();
            	//
            	//eletron 3 diagonal
            	glPushMatrix();
            		glRotatef(spin, 1.0, 1.0, 0.0);
            		//
            		glPushMatrix();
            			glTranslatef(0.0,0.0,40.0);
            			particula(1, 2.5, 50.0, 50.0);
            		glPopMatrix();
            		//
            	glPopMatrix();
            	//
            	//eletron 4 diagonal 2
            	glPushMatrix();
            		glRotatef(spin, 1.0, -1.0, 0.0);
            		//
            		glPushMatrix();
            			glTranslatef(0.0,0.0,-40.0);
            			particula(1, 2.5, 50.0, 50.0);
            		glPopMatrix();
            		//
            	glPopMatrix();


            	//eletron trajeto 1 horinzontal
            	glEnable(GL_TEXTURE_2D);

            	glActiveTexture(GL_TEXTURE0);
            	glBindTexture(GL_TEXTURE_2D, textures[3]);
            
            	glPushMatrix();
            		glRotatef(90.0, 1.0, 0.0, 0.0);
            		glutSolidTorus(0.20,40.0,25.0,25.0);
            		//
            	glPopMatrix();
            	//
            	//eletron trajeto 2 vertical
           		glPushMatrix();
            		glRotatef(90.0, 0.0, 1.0, 0.0);
            		glutSolidTorus(0.20,40.0,25.0,25.0);
            		//
            	glPopMatrix();
            	//
           		//eletron trajeto 3 diagonal
            	glPushMatrix();
            		glRotatef(90.0,1.0,1.0,0.0);
            		glutSolidTorus(0.2,40.0,25.0,25.0);
            		//
            	glPopMatrix();
            	//
            	//eletron trajeto 4 diagonal
           		glPushMatrix();
            		glRotatef(90.0,1.0,-1.0,0.0);
            		glutSolidTorus(0.2,40.0,25.0,25.0);
            		//
            	glPopMatrix();

            	glDisable(GL_TEXTURE_2D);
            glPopMatrix();
        }
    }

    glPopMatrix();

    glUseProgram(0);

    glutSwapBuffers();

    glutPostRedisplay();
}

void particula(int ID, double radius, int slices, int stacks)
{
    glRotatef(90, 1.0, 0.0, 0.0);
    glEnable(GL_TEXTURE_2D);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textures[ID]);

    GLUquadric *quad = gluNewQuadric();
    gluQuadricDrawStyle( quad, GLU_FILL);
    gluQuadricNormals( quad, GLU_SMOOTH);
    gluQuadricOrientation( quad, GLU_OUTSIDE);
    gluQuadricTexture( quad, GL_TRUE);

    gluSphere(quad, radius, slices, stacks);

    glDisable(GL_TEXTURE_2D);
}

void reshape(int w, int h)
{

    if(h == 0)
    {
        h = 1;
    }
    width = w;
    height = h;
    glViewport (0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fovy, (float)w/(float)h, 1.0, 10000.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(move_cx,move_cy,move_cz, move_cx,0.0,move_fz, 0.0,move_uy,0.0);

	float position[4] = {0.0f, 0.0f, 0.0f, 1.0f};
	float ambient[4] =  {0.2f, 0.2f, 0.2f, 1.0f};
	float diffuse[4] =  {0.8f, 0.8f, 0.8f, 1.0f};
	float specular[4] = {0.2f, 0.2f, 0.2f, 1.0f};
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glLightfv(GL_LIGHT0, GL_AMBIENT,  ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	GLfloat shine[1] = {3.0};
	glMaterialfv(GL_FRONT, GL_SHININESS, shine);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);

	GLfloat	luzAmbiente[4]={1.0, 1.0, 1.0, 1.0};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente);
/*	
    float position[4] = {0.0, 0.0, 0.0, 0.0};
    float ambient[4]  = {0.2, 0.2, 0.2, 1.0};
    float diffuse[4]  = {0.7, 0.7, 0.7, 1.0};
    float specular[4] = {0.0, 0.5, 0.5, 1.0};
    glLightfv(GL_LIGHT0, GL_POSITION, position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

    glMaterialf(GL_FRONT, GL_SHININESS, 16.0);
*/
    //printf("%d %d\n", w, h);
}

void mouse(int button, int state, int x, int y)
{
    switch (button)
    {
    case GLUT_LEFT_BUTTON:
        if (state == GLUT_DOWN)
        {
            if(rot == 1)
            {
                rot = 0;
            }
            else
            {
                rot = 1;
            }
        }
        printf("LEFT BUTTON\n");
        break;
    case GLUT_MIDDLE_BUTTON:
        if (state == GLUT_DOWN)
        {
            fovy = 45.0;
        }
        printf("MIDDLE BUTTON\n");
        break;
    case GLUT_RIGHT_BUTTON:
        if (state == GLUT_DOWN)
        {
            //mexer camera
        }
        printf("RIGHT BUTTON\n");
        break;
    case 3:
        fovy *= 0.99;
        printf("ZOOM IN\n");
        break;
    case 4:
        fovy *= 1.01;
        printf("ZOOM OUT\n");
        break;
    default:
        printf("button: %d\n",button);
        break;
    }
    reshape(width, height);
}

void motion(int x, int y)
{
    //printf("Motion: %d %d\n", x, y);
}

void special(int key, int x, int y)
{
    switch(key)
    {
    case GLUT_KEY_LEFT:
        move_cx += 1.0;
        printf("LEFT KEY\n");
        break;
    case GLUT_KEY_RIGHT:
        move_cx -= 1.0;
        printf("RIGHT KEY\n");
        break;

    case GLUT_KEY_UP:
        move_cz += 1.0;
        move_fz = move_cz +100.0;
        printf("UP KEY\n");
        break;
    case GLUT_KEY_DOWN:
        move_cz -= 1.0;
        move_fz = move_cz +100.0;
        printf("DOWN KEY\n");
        break;

    case GLUT_KEY_PAGE_UP:
        move_cy += 1.0;
        printf("PAGE UP KEY\n");
        break;
    case GLUT_KEY_PAGE_DOWN:
        move_cy -= 1.0;
        printf("PAGE DOWN KEY\n");
        break;

    case GLUT_KEY_F1:
        velo -= 0.10;
        printf("F1 KEY\n");
        break;
    case GLUT_KEY_F2:
        velo += 0.10;
        printf("F2 KEY\n");
        break;

    case GLUT_KEY_F3:
        velo = 1.0;
        printf("F3 KEY\n");
        break;
    case GLUT_KEY_F4:
        move_cx = 100.0;
        move_cy = 50.0;
        move_cz = -100.0;
        move_fz = 0.0;
        printf("F4 KEY\n");
        break;
        
    case GLUT_KEY_HOME:
    	move_uy *= -1.0;
        printf("HOME KEY\n");
		break;
		
    case GLUT_KEY_F12:
        printf("F12 KEY\n");
        exit(0);
        break;

    default:
        //só printa keys especiais
        printf("KEY: %d\n",key);
        break;
    }
    reshape(width, height);
}
